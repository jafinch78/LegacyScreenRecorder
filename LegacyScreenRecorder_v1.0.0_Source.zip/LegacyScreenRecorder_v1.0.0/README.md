# Legacy Screen Recorder v1.0.0

Standalone, offline Android recorder targeting the Galaxy J3 Luna Pro (Android 6.0.1 / API 23), Galaxy S8+ (Android 9 / API 28), and Galaxy A35 5G (Android 15 / API 35). Native Java, no third-party app libraries. Reimplements the MediaProjection + MediaRecorder pattern documented for Toyota CAN Sync; not a direct source fork. No BLE, CAN, GPS, account, analytics, camera, or networking features.

## Build

Open this folder (not `app`) in Android Studio. Use SDK Platform 35, Android Gradle Plugin 8.7.3, Gradle 8.9, and JDK 17 (or a Gradle-compatible newer JDK). Minimum SDK is 23; do not raise it. The Gradle distribution is not bundled. Select the local Gradle 8.9 distribution in Android Studio if prompted. Alternatively run `BUILD_APK.bat` on Windows using your existing Gradle installation (`C:\Gradle\gradle-8.9` or `GRADLE_HOME`). First-time dependency resolution needs internet; recording itself does not. Review BUILD_LAST.log on failure.

Build > Generate App Bundles or APKs > Generate APKs, or use the BAT. Output: `app\build\outputs\apk\debug\app-debug.apk`. Copy it to the phone and allow installation from that file source, or enable USB debugging and use Android Studio Run / `adb install -r app-debug.apk` from its output folder. The debug build is locally signed by your Android SDK; no production signing key is provided.

## Record

1. Open Screen Recorder. Economy is the default on Android 6/7, Standard on Android 8+.
2. Select quality and microphone on/off. Grant microphone (if enabled), legacy storage (API <=28), and notifications (API >=33) when requested.
3. Press START RECORDING and approve the Android screen-sharing dialog. Android 14+ requests the default display (whole screen); select entire screen if the system offers a choice. Start only after the status shows RECORDING.
4. Return home and use any app. Stop from the persistent notification or the recorder's STOP & SAVE button. Wait until SAVED before transferring the video.
5. Find `SCREEN_yyyyMMdd_HHmmss_SSS.mp4` in internal shared storage `Movies/LegacyScreenRecorder/` via Gallery/My Files or USB MTP. No metadata JSON or ZIP required.

| Preset | Target short side | FPS | Video bit rate | Approx. with mic |
|---|---:|---:|---:|---:|
| Economy | 480 | 10 | 1 Mb/s | 0.49 GB/h |
| Standard | 720 | 20 | 2.5 Mb/s | 1.17 GB/h |
| High | 1080 | 30 | 6 Mb/s | 2.74 GB/h |

Dimensions fit the actual display without upscaling; long side capped at 1920 and both sides rounded down to multiples of 16 for older AVC encoders. Preset FPS/bitrate are requests, not measured actual output. A prepare failure tries lower presets before creating a virtual display. If the encoder fails at start, an error is shown; try Economy manually. Microphone audio is mono AAC 44.1 kHz / 96 kbps. No direct app/device playback audio, even on Android 10+ in this initial build. Older phones lack the public playback capture API. Screen-lock behavior depends on OS; keep the screen awake/unlocked and do not force-stop or power off while recording. Rotation uses the original encoder geometry, so keep the same orientation during a recording; older Android may crop, stretch or letterbox after rotation. Stop/restart in the new orientation. Secure/DRM content may be blank. Recording stops when OS withdraws projection, on explicit stop, encoder error, or configured file-size limit. Legacy API 23–28 clips have a 3500 MiB cap; all versions reserve about 128 MiB free storage at startup, but concurrent storage use may exhaust space earlier. No automatic continuation after stop.

## Failure handling

The foreground service starts before acquiring projection, registers revocation callback before creating one virtual display, and performs encoder/storage work on its own handler thread. A partial wake lock is held only for the recording lifecycle. API 23–28 uses an unpublished `.mp4.partial` file and scans the completed MP4; API 29+ uses a pending MediaStore entry. On stop, resources are released and video metadata (positive duration, width, height) is read back before publishing. This is a container-level sanity check, not a guarantee every frame or audio sample is decodable. Failed setup removes partial output; unreadable captures after recording started remain unpublished where possible (pending modern MediaStore items may expire automatically). The app reports SAVED only after a successful publication. Very short clips may fail encoder finalization; record at least several seconds. Android process kill or abrupt power loss can leave an unplayable file. No upload or network permission.

## Verification and device acceptance tests

Source-only delivery; no APK compiled or installed in the authoring environment. See TEST_REPORT.md for executed checks. On each real phone:

- Confirm installation and microphone/notification/storage consent paths as applicable. Deny screen sharing and verify recording does not start.
- Economy: record 30 seconds while scrolling text, switch to another app, speak continuously, then stop from notification. Play in Gallery, confirm full-screen text, correct orientation, audible narration, duration and seekability. Copy via USB and inspect resolution/frame rate if desired.
- Repeat microphone off; verify no audio track. Stop from app as well. Repeat 5 start/stop cycles, confirm distinct MP4 names and no stale recording state.
- Test Standard and High only if lower presets pass. Record 10 minutes with apps in foreground, check for heat, audio dropouts, lag, file integrity. Keep orientation fixed. Verify revoked projection / screen lock ends or behaves as documented on each OS.
- Test low space on a spare device without filling critical storage. Confirm understandable errors and no false SAVED state. Test screen rotation separately; stop/restart if clipping occurs.

References: https://developer.android.com/media/grow/media-projection ; https://developer.android.com/media/platform/av-capture ; https://developer.android.com/build/releases/agp-8-7-0-release-notes
