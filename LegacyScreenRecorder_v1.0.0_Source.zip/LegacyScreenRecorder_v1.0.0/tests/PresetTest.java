package com.legacy.screenrecorder;
public class PresetTest {
 public static void main(String[] args) {
  int cases=0;
  int[][] screens={{720,1280},{1440,2960},{1080,2340},{1280,720},{2960,1440},{2340,1080},{480,800},{800,480},{320,480}};
  for(int[] screen:screens) for(int i=0;i<3;i++) {
   int[] a=Preset.dimensions(screen[0],screen[1],i);
   if(a[0]>screen[0]||a[1]>screen[1]||a[0]%16!=0||a[1]%16!=0||Math.max(a[0],a[1])>1920||Math.min(a[0],a[1])>new int[]{480,720,1080}[i]||a[2]!=new int[]{10,20,30}[i]||a[3]!=new int[]{1000000,2500000,6000000}[i]) throw new AssertionError("Preset constraint");
   double aspect=(double)a[0]/a[1], original=(double)screen[0]/screen[1];
   if(Math.abs(aspect/original-1)>0.06) throw new AssertionError("Aspect error");
   cases++;
  }
  try { Preset.dimensions(0,720,0); throw new AssertionError("Invalid size accepted"); } catch(IllegalArgumentException expected) { cases++; }
  try { Preset.dimensions(720,1280,3); throw new AssertionError("Invalid preset accepted"); } catch(IllegalArgumentException expected) { cases++; }
  System.out.println("PASS: "+cases+" preset cases");
 }
}
