package com.legacy.screenrecorder;

final class Preset {
    private static final int[] SHORT={480,720,1080}, FPS={10,20,30}, RATE={1000000,2500000,6000000};
    // Align to 16 pixels for older AVC hardware, never upscale, preserve aspect approximately.
    static int[] dimensions(int w,int h,int p) {
        if(w<16||h<16||p<0||p>2) throw new IllegalArgumentException("Invalid display or preset");
        double factor=Math.min(1.0,Math.min((double)SHORT[p]/Math.min(w,h), (double)1920/Math.max(w,h)));
        int x=Math.max(16,((int)(w*factor)/16)*16), y=Math.max(16,((int)(h*factor)/16)*16);
        return new int[]{x,y,FPS[p],RATE[p]};
    }
}
