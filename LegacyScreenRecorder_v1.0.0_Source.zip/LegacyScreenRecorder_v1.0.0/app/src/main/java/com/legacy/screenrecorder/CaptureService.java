package com.legacy.screenrecorder;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.*;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class CaptureService extends Service {
    static final String START="com.legacy.screenrecorder.START", STOP="com.legacy.screenrecorder.STOP";
    private static final String CHANNEL="recording";
    private static final int NOTICE=42;
    static volatile String state="IDLE", message="Ready";
    static volatile long startedAt;
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private VirtualDisplay display;
    private MediaRecorder recorder;
    private ParcelFileDescriptor fd;
    private Uri outputUri;
    private File tempFile, finalFile;
    private PowerManager.WakeLock wake;
    private boolean recording, finishing;
    private String filename, selected;
    private final MediaProjection.Callback projectionCallback=new MediaProjection.Callback() {
        @Override public void onStop() { finish("Screen sharing ended",null); }
    };
    @Override public void onCreate() {
        super.onCreate(); thread=new HandlerThread("ScreenRecorder"); thread.start(); worker=new Handler(thread.getLooper());
        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel(CHANNEL,"Screen recording",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public int onStartCommand(Intent i,int flags,int id) {
        if(i==null) { if(state.equals("IDLE")) stopSelf(); return START_NOT_STICKY; }
        if(STOP.equals(i.getAction())) {
            if(state.equals("IDLE")) stopSelf(); else worker.post(() -> finish("Stopped",null));
            return START_NOT_STICKY;
        }
        if(!START.equals(i.getAction())) { if(state.equals("IDLE")) stopSelf(); return START_NOT_STICKY; }
        if(!state.equals("IDLE")) return START_NOT_STICKY;
        state="STARTING"; message="Preparing screen recording…";
        try {
            boolean mic=i.getBooleanExtra("mic",true);
            if(Build.VERSION.SDK_INT>=29) {
                int type=ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if(mic && Build.VERSION.SDK_INT>=30) type|=ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
                startForeground(NOTICE,notification("Preparing…",false),type);
            } else startForeground(NOTICE,notification("Preparing…",false));
            worker.post(() -> startCapture(i));
        } catch(Exception e) { worker.post(() -> finish("Unable to start foreground recorder",e)); }
        return START_NOT_STICKY;
    }
    private Notification notification(String text,boolean running) {
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),flags);
        PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction(STOP),flags);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_record).setContentTitle("Screen Recorder").setContentText(text).setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
         .addAction(new Notification.Action.Builder(R.drawable.ic_record,"STOP & SAVE",stop).build());
        if(running) b.setWhen(System.currentTimeMillis()).setUsesChronometer(true).setShowWhen(true);
        return b.build();
    }
    private void startCapture(Intent i) {
        try {
            if(finishing) return;
            int width=i.getIntExtra("width",0), height=i.getIntExtra("height",0), density=i.getIntExtra("density",160);
            if(width<=0||height<=0) throw new IOException("Invalid display dimensions");
            int preset=Math.max(0,Math.min(2,i.getIntExtra("preset",0)));
            boolean mic=i.getBooleanExtra("mic",true);
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            wake=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"LegacyScreenRecorder:Capture"); wake.setReferenceCounted(false); wake.acquire();
            Intent consent=i.getParcelableExtra("consent");
            if(consent==null) throw new IOException("Missing screen capture permission");
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(i.getIntExtra("result",Activity.RESULT_CANCELED),consent);
            if(projection==null) throw new IOException("Screen sharing permission unavailable");
            projection.registerCallback(projectionCallback,worker);
            Exception last=null; int[] chosen=null;
            // Try the requested preset, then lower presets, before creating the one allowed virtual display.
            for(int p=preset;p>=0;p--) {
                int[] config=Preset.dimensions(width,height,p);
                try {
                    prepareOutput();
                    recorder=new MediaRecorder();
                    if(mic) recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
                    recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
                    recorder.setVideoSize(config[0],config[1]); recorder.setVideoFrameRate(config[2]); recorder.setVideoEncodingBitRate(config[3]);
                    if(mic) { recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); recorder.setAudioChannels(1); recorder.setAudioSamplingRate(44100); recorder.setAudioEncodingBitRate(96000); }
                    recorder.setMaxFileSize(maxBytes());
                    if(fd!=null) recorder.setOutputFile(fd.getFileDescriptor()); else recorder.setOutputFile(tempFile.getAbsolutePath());
                    recorder.setOnErrorListener((r,what,extra)->finish("Recorder error "+what+"/"+extra,new IOException("Encoder error")));
                    recorder.setOnInfoListener((r,what,extra)-> { if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED||what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) finish("Recording limit reached",null); });
                    recorder.prepare(); chosen=config; break;
                } catch(Exception e) { last=e; Log.w("LegacyScreenRecorder","Preset "+p+" prepare failed",e); releaseRecorder(); discardOutput(); }
            }
            if(chosen==null) throw new IOException("No preset could start: "+(last==null?"unknown":last.getMessage()),last);
            selected=chosen[0]+"×"+chosen[1]+" / "+chosen[2]+" fps / "+(mic?"microphone":"silent");
            display=projection.createVirtualDisplay("LegacyScreenRecorder",chosen[0],chosen[1],density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,recorder.getSurface(),null,worker);
            if(display==null) throw new IOException("Could not create screen display");
            recorder.start(); recording=true; startedAt=SystemClock.elapsedRealtime();
            message="RECORDING\n"+selected; state="RECORDING";
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTICE,notification(selected,true));
        } catch(Exception e) { finish("Recording failed",e); }
    }
    private void prepareOutput() throws IOException {
        filename="SCREEN_"+new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date())+".mp4";
        if(Build.VERSION.SDK_INT>=29) {
            ContentValues values=new ContentValues(); values.put(MediaStore.Video.Media.DISPLAY_NAME,filename); values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); values.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/LegacyScreenRecorder/"); values.put(MediaStore.Video.Media.IS_PENDING,1);
            outputUri=getContentResolver().insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),values);
            if(outputUri==null) throw new IOException("Could not create video file");
            fd=getContentResolver().openFileDescriptor(outputUri,"rw"); if(fd==null) throw new IOException("Could not open video file");
        } else {
            File folder=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),"LegacyScreenRecorder");
            if(!folder.isDirectory()&&!folder.mkdirs()) throw new IOException("Cannot create Movies folder");
            finalFile=new File(folder,filename); tempFile=new File(folder,filename+".partial");
            if(!tempFile.createNewFile()) throw new IOException("Output already exists");
        }
    }
    private long maxBytes() throws IOException {
        long available=new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath()).getAvailableBytes();
        long limit=available-128L*1024*1024;
        if(limit<32L*1024*1024) throw new IOException("Insufficient free storage (need at least 160 MiB)");
        // Legacy filesystems and vendor recorders may impose a 4 GiB limit.
        return Build.VERSION.SDK_INT<=28?Math.min(limit,3500L*1024*1024):limit;
    }
    private void releaseRecorder() {
        if(recorder!=null) { try { recorder.reset(); } catch(Exception ignored) {} try { recorder.release(); } catch(Exception ignored) {} recorder=null; }
        if(fd!=null) { try { fd.close(); } catch(Exception ignored) {} fd=null; }
    }
    private void discardOutput() {
        if(outputUri!=null) { try { getContentResolver().delete(outputUri,null,null); } catch(Exception e) { Log.w("LegacyScreenRecorder","Pending output cleanup failed",e); } outputUri=null; }
        if(tempFile!=null) { if(tempFile.exists()&&!tempFile.delete()) Log.w("LegacyScreenRecorder","Partial file cleanup failed"); tempFile=null; }
        finalFile=null;
    }
    // Read back the finalized container before exposing it to the gallery.
    private boolean verifyVideo() {
        MediaMetadataRetriever check=new MediaMetadataRetriever();
        try {
            if(outputUri!=null) check.setDataSource(this,outputUri);
            else if(tempFile!=null) check.setDataSource(tempFile.getAbsolutePath());
            else return false;
            String duration=check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            String width=check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String height=check.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            return duration!=null && width!=null && height!=null && Long.parseLong(duration)>0 && Integer.parseInt(width)>0 && Integer.parseInt(height)>0;
        } catch(Exception e) { Log.w("LegacyScreenRecorder","MP4 readback failed",e); return false; }
        finally { try { check.release(); } catch(Exception ignored) {} }
    }
    private void publishOutput() throws IOException {
        if(outputUri!=null) {
            ContentValues v=new ContentValues(); v.put(MediaStore.Video.Media.IS_PENDING,0);
            if(getContentResolver().update(outputUri,v,null,null)!=1) throw new IOException("Unable to publish video");
            outputUri=null;
        } else {
            if(tempFile==null||tempFile.length()==0||!tempFile.renameTo(finalFile)) throw new IOException("Unable to finalize MP4; check partial file in Movies");
            MediaScannerConnection.scanFile(this,new String[]{finalFile.getAbsolutePath()},new String[]{"video/mp4"},null); tempFile=null; finalFile=null;
        }
    }
    private void finish(String reason,Exception error) {
        if(finishing) return; finishing=true; state="STOPPING"; message="Finalizing MP4…";
        boolean hadRecording=recording;
        if(recording && recorder!=null) {
            try { recorder.stop(); } catch(RuntimeException e) { if(error==null) error=e; }
        }
        recording=false;
        if(display!=null) { try { display.release(); } catch(Exception ignored) {} display=null; }
        releaseRecorder();
        if(projection!=null) { try { projection.unregisterCallback(projectionCallback); projection.stop(); } catch(Exception ignored) {} projection=null; }
        if(hadRecording && verifyVideo()) {
            try { publishOutput(); message="SAVED\n"+filename+"\n"+selected+"\n"+reason+(error!=null?" (recording ended with an error)":""); }
            catch(Exception e) { error=e; message="FINALIZATION FAILED\n"+e.getMessage(); /* Retain unpublished/partial file for possible recovery. */ }
        } else {
            if(!hadRecording) discardOutput();
            message="NOT SAVED\n"+reason+(error==null?"":"\n"+error.getClass().getSimpleName()+": "+error.getMessage());
            if(hadRecording) message+="\nMP4 could not be verified; unpublished output retained where possible: "+filename;
        }
        if(error!=null) Log.e("LegacyScreenRecorder",reason,error);
        if(wake!=null) { try { if(wake.isHeld()) wake.release(); } catch(Exception ignored) {} wake=null; }
        getSharedPreferences("capture",0).edit().putString("last",message).apply();
        new Handler(Looper.getMainLooper()).post(() -> { stopForeground(true); stopSelf(); });
    }
    @Override public void onDestroy() {
        if(worker!=null) worker.post(() -> { if(!finishing) finish("Service stopped",null); state="IDLE"; thread.quitSafely(); });
        super.onDestroy();
    }
}
