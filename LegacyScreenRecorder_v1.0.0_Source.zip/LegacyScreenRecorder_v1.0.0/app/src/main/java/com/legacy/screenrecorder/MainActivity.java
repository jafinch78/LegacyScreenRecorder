package com.legacy.screenrecorder;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int PERMISSIONS = 10, PROJECTION = 11;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Spinner preset;
    private CheckBox microphone;
    private Button start, stop;
    private TextView status;
    private boolean consentPending;
    private final Runnable refresh = new Runnable() {
        public void run() { render(); handler.postDelayed(this, 500); }
    };
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        consentPending = saved != null && saved.getBoolean("consentPending");
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20),dp(20),dp(20),dp(20));
        scroll.addView(layout);
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom); return insets;
            });
        }
        setContentView(scroll);
        TextView title = new TextView(this); title.setText("Screen Recorder"); title.setTextSize(27); title.setTypeface(null, 1); layout.addView(title);
        TextView info = new TextView(this); info.setText("Full screen • MP4 • Offline\nAndroid " + Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT); info.setTextSize(15); layout.addView(info);
        TextView q = new TextView(this); q.setText("\nRecording quality"); layout.addView(q);
        preset = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Economy — 480p / 10 fps", "Standard — 720p / 20 fps", "High — up to 1080p / 30 fps"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); preset.setAdapter(adapter);
        preset.setSelection(getPreferences(0).getInt("preset", Build.VERSION.SDK_INT <= 25 ? 0 : 1)); layout.addView(preset);
        microphone = new CheckBox(this); microphone.setText("Record microphone audio"); microphone.setChecked(getPreferences(0).getBoolean("mic", true)); layout.addView(microphone);
        start = new Button(this); start.setText("START RECORDING"); start.setOnClickListener(v -> begin()); layout.addView(start);
        stop = new Button(this); stop.setText("STOP & SAVE"); stop.setOnClickListener(v -> startService(new Intent(this,CaptureService.class).setAction(CaptureService.STOP))); layout.addView(stop);
        status = new TextView(this); status.setTextSize(16); status.setPadding(0,dp(16),0,dp(16)); status.setTextIsSelectable(true); layout.addView(status);
        TextView help = new TextView(this); help.setText("Videos: Internal storage / Movies / LegacyScreenRecorder\n\nAfter starting, open any app. Stop from the notification or return here. Keep the same screen orientation for the best result. Protected screens may be black. Microphone only; internal app audio is not captured."); layout.addView(help);
        render();
    }
    @Override protected void onSaveInstanceState(Bundle b) { b.putBoolean("consentPending",consentPending); super.onSaveInstanceState(b); }
    @Override protected void onResume() { super.onResume(); handler.removeCallbacks(refresh); handler.post(refresh); }
    @Override protected void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
    private void render() {
        boolean idle = CaptureService.state.equals("IDLE");
        start.setEnabled(idle && !consentPending); stop.setEnabled(!idle && !CaptureService.state.equals("STOPPING")); preset.setEnabled(idle && !consentPending); microphone.setEnabled(idle && !consentPending);
        String s = CaptureService.message;
        if (idle && s.equals("Ready")) s = getSharedPreferences("capture",0).getString("last","Ready");
        if (CaptureService.state.equals("RECORDING")) {
            long t = Math.max(0,(SystemClock.elapsedRealtime()-CaptureService.startedAt)/1000);
            s += String.format(Locale.US,"\n%02d:%02d:%02d",t/3600,(t/60)%60,t%60);
        }
        status.setText(s);
    }
    private void begin() {
        if (!CaptureService.state.equals("IDLE") || consentPending) return;
        ArrayList<String> missing = new ArrayList<>();
        if (microphone.isChecked() && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) { requestPermissions(missing.toArray(new String[0]),PERMISSIONS); return; }
        getPreferences(0).edit().putInt("preset",preset.getSelectedItemPosition()).putBoolean("mic",microphone.isChecked()).apply();
        MediaProjectionManager m = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        try {
            Intent intent = Build.VERSION.SDK_INT >= 34 ? m.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay()) : m.createScreenCaptureIntent();
            consentPending = true; render(); startActivityForResult(intent,PROJECTION);
        } catch (Exception e) { consentPending=false; Toast.makeText(this,"Screen capture unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show(); render(); }
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request,permissions,results);
        if (request != PERMISSIONS) return;
        for(int r:results) if(r!=PackageManager.PERMISSION_GRANTED) { Toast.makeText(this,"Permission denied. Enable it in Settings or disable microphone if only audio was denied.",Toast.LENGTH_LONG).show(); return; }
        if(results.length>0) begin();
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=PROJECTION) return;
        consentPending=false;
        if(result!=RESULT_OK || data==null) { Toast.makeText(this,"Screen capture cancelled",Toast.LENGTH_SHORT).show(); render(); return; }
        if(!CaptureService.state.equals("IDLE")) return;
        DisplayMetrics dm=new DisplayMetrics(); getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        Intent i=new Intent(this,CaptureService.class).setAction(CaptureService.START);
        i.putExtra("consent",data).putExtra("result",result).putExtra("width",dm.widthPixels).putExtra("height",dm.heightPixels).putExtra("density",dm.densityDpi).putExtra("preset",preset.getSelectedItemPosition()).putExtra("mic",microphone.isChecked());
        try { if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }
        catch(Exception e) { Toast.makeText(this,"Cannot start: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
        render();
    }
}
