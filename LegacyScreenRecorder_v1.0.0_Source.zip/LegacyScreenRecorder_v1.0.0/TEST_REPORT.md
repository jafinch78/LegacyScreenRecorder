# Source validation — v1.0.0

Executed in the authoring environment:
- PASS: Java compiler parser (Java 8 language mode), all three application Java files. Syntax only; Android classes and API linkages not compiled.
- PASS: compiled and ran pure Java preset tests (29 cases: nine screen geometries × three presets, plus two invalid inputs). Checks alignment, no upscaling, resolution bounds, approximate aspect, FPS, bitrate.
- PASS: XML parsing of manifest, theme and icon.
- PASS: static checks for minimum SDK 23, no Internet/BLE/location permissions, private capture service, one virtual display creation site, registration before virtual display creation, output metadata verification gate.

Not run: Android Gradle build, Android lint, emulator, actual phone recording, audio capture, storage limits, notification behavior, rotation, thermal or prolonged recording. No Android SDK or Gradle installed in the authoring environment. BUILD_APK.bat runs Gradle assembly and lint on Windows. Device acceptance checklist is in README.md. Source validation is not field certification.
